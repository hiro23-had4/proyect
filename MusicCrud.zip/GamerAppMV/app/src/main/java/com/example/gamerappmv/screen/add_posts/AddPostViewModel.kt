package com.example.gamerappmv.screen.add_posts

import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gamerappmv.R
import com.example.gamerappmv.domain.model.Post
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.use_cases.auth.AuthUseCase
import com.example.gamerappmv.domain.use_cases.post.PostUserCases
import com.example.gamerappmv.screen.add_posts.components.AddPostState
import com.example.gamerappmv.utils.ComposeFileProvider
import com.example.gamerappmv.utils.ResultingActivityHandler
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class AddPostViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val postUserCases: PostUserCases,
    private val authUseCase: AuthUseCase
    ): ViewModel() {

    var state by mutableStateOf(AddPostState())

    //FILE
    var file: File? = null
    val resultingActivityHandler = ResultingActivityHandler()

    //almacenar el estado en el que se encuntra la peticion
    var createPostResponse by mutableStateOf<Response<Boolean>?>(null)
        private set

    //USER SESSION
    val currentUser = authUseCase.getCurrentUser()

    val radioOptions = listOf(
        CategoryRadioButton("Rock", R.drawable.img_rock),
        CategoryRadioButton("Pop", R.drawable.img_pop),
        CategoryRadioButton("Electronic", R.drawable.img_electro),
        CategoryRadioButton("Hip-Hop/Rap", R.drawable.img_hiphop),
        CategoryRadioButton("Reggae", R.drawable.img_reggae)
    )

    fun createPost(post: Post) = viewModelScope.launch {
        createPostResponse = Response.Loading // progress bar
        val result = postUserCases.create(post, file!!)
        createPostResponse = result
    }

    fun onNewPost() {
        /*Log.d("AddPostViewModel", "name: ${state.name}")
        Log.d("AddPostViewModel", "descripcion: ${state.description}")
        Log.d("AddPostViewModel", "categoria: ${state.category}")
        Log.d("AddPostViewModel", "image: ${state.image}")*/
        val post = Post(
            name = state.name,
            description = state.description,
            category = state.category,
            idUser = currentUser?.uid ?: ""
        )
        createPost(post)
    }

    //ACCEDER GALLERY
    fun pickImage() = viewModelScope.launch {
        val result = resultingActivityHandler.getContent("image/*")
        if (result != null) {
            file = ComposeFileProvider.createFileFromUri(context, result)
            state = state.copy(image = result.toString())
        }
    }

    //ACCEDER A LA CAMARA
    fun takePhoto() = viewModelScope.launch {
        val result = resultingActivityHandler.takePicturePreview()
        if (result != null) {
            state = state.copy(image = ComposeFileProvider.getPathFromBitmap(context, result))
            file = File(state.image)
        }
    }

    //DEJAR EL FORMULARIO VACIO
    fun clearForm() {
        state = state.copy(
            name = "",
            description = "",
            category = "",
            image = ""
        )
        createPostResponse = null
    }

    fun onImageInput(image: String) {
        state = state.copy(image = image)
    }
    fun onNameInput(name: String) {
        state = state.copy(name = name)
    }
    fun onCategoryInput(category: String) {
        state = state.copy(category = category)
    }
    fun onDescriptionInput(description: String) {
        state = state.copy(description = description)
    }
}

data class CategoryRadioButton(
    var category: String,
    var image: Int
)