package com.example.gamerappmv.screen.login

data class LoginState(
    val email: String = "",
    val password: String = ""
)
