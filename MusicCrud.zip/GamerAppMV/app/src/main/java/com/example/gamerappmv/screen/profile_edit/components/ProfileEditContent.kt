package com.example.gamerappmv.screen.profile_edit.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.gamerappmv.R
import com.example.gamerappmv.reusable.ButtomPredetermined
import com.example.gamerappmv.reusable.DefaultTextField
import com.example.gamerappmv.reusable.DialogCapturePicture
import com.example.gamerappmv.screen.profile_edit.ProfileEditViewModel
import com.example.gamerappmv.ui.theme.Darkgray500
import com.example.gamerappmv.ui.theme.Red500

@Composable
fun ProfileEditContent(
    navController: NavController,
    viewModel: ProfileEditViewModel = hiltViewModel()
) {

    val state = viewModel.state
    viewModel.resultingActivityHandler.handle()

    var dialogState = remember { mutableStateOf(false) }
    DialogCapturePicture(
        status = dialogState ,
        takePhoto = { viewModel.takePhoto() },
        pickImage = { viewModel.pickImage() }
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .background(Red500)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(40.dp))
                // ACCEDER A LA GALLERY
                if (viewModel.state.image != "") {
                    AsyncImage(
                        modifier = Modifier
                            .height(150.dp)
                            .width(150.dp)
                            .clip(CircleShape)
                            .clickable {
                                dialogState.value = true
                            },
                        contentScale = ContentScale.Crop,
                        model = viewModel.state.image,
                        contentDescription = "Selected image"
                    )
                } else {
                    Image(
                        modifier = Modifier
                            .height(130.dp)
                            .clickable {
                                dialogState.value = true
                            },
                        painter = painterResource(id = R.drawable.user),
                        contentDescription = "Image User"
                    )
                } // fin de la Gallery
            }
        }
        Card(
            modifier = Modifier
                .padding(start = 40.dp, end = 40.dp, top = 200.dp),
            backgroundColor = Darkgray500
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp)
            ) {
                Text(
                    modifier = Modifier.padding(top = 40.dp),
                    text = "ACTUALIZACION",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Por favor Ingresa tus datos para continuar",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                DefaultTextField(
                    modifier = Modifier.padding(top = 25.dp),
                    value = state.username,
                    onValueChange = { viewModel.onUsernameInput(it) },
                    label = "Nombre de Usuario",
                    icon = Icons.Default.Person,
                    errorMsg = viewModel.usernameErrMsg,
                    validateField = {
                        viewModel.validateUsername()
                    }
                )
                ButtomPredetermined(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 20.dp, bottom = 40.dp),
                    text = "ACTUALIZAR DATOS",
                    onClick = {
                        viewModel.saveImage()
                        //navController.navigate(AppScreen.ProfileScreen.route)
                    }
                )
            }
        }
    }
}