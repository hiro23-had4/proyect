package com.example.gamerappmv.data

import android.net.Uri
import com.example.gamerappmv.core.Constants.USERS
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.model.User
import com.example.gamerappmv.domain.repository.UsersRepository
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File
import javax.inject.Inject
import javax.inject.Named

//HACER UNA INYECCION, PERO CON LA BASE DE DATOS FIREBASESTORE
class UsersRepositoryImpl @Inject constructor(
    @Named(USERS) private val usersRef: CollectionReference,
    @Named(USERS) private val storageUserRef: StorageReference
): UsersRepository {

    override suspend fun create(user: User): Response<Boolean> {
        return try {
            user.password = ""
            usersRef.document(user.id).set(user).await()
            Response.Success(true)
        }catch (e: Exception){
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    override suspend fun update(user: User): Response<Boolean> { // actualizar la informacion del registro
        return try {
            val map: MutableMap<String, Any> = HashMap()
            map["username"] = user.username //campos a actualizar
            map["image"] = user.image
            usersRef.document(user.id).update(map).await()
            Response.Success(true)
        }catch (e: Exception){
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    override suspend fun saveImage(file: File): Response<String> {
        return try {
            val fromFile = Uri.fromFile(file)
            val ref = storageUserRef.child(file.name)
            val uploadTask = ref.putFile(fromFile).await() // funcion asincrona
            val url = ref.downloadUrl.await()
            return Response.Success(url.toString())
        }catch (e: Exception){
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    override fun getUserById(id: String): Flow<User> = callbackFlow {
        val snapshotListener = usersRef.document(id).addSnapshotListener{ snapshot, e ->
            val user = snapshot?.toObject(User::class.java) ?: User()
            trySend(user) // emitir la informacion cuando sea requerida
        }
        awaitClose {
            snapshotListener.remove() // eliminar los escuchadores
        }
    }
}

/*
    FORMA #1
    SE COLOCA UNA VARIABLE PARA ENTRAR A FIRESTORE
    val firebase = Firebase.firestore
    Y SE CREARIA LA COLLECTION
    val userRef = firestore.collection("User")
* */
