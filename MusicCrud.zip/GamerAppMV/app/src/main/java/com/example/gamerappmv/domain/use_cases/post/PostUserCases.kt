package com.example.gamerappmv.domain.use_cases.post

data class PostUserCases(
    val create: CreatePost,
    val getPost: GetPost,
    val getPostByIdUser: GetPostByIdUser,
    val likePost: LikePost,
    val deleteLikePost: DeleteLikePost
)
