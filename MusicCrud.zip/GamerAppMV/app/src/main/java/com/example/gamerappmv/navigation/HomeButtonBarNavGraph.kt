package com.example.gamerappmv.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.List
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.gamerappmv.screen.my_posts.MyPostsScreen
import com.example.gamerappmv.screen.pantallaone.screens.ProfileScreen
import com.example.gamerappmv.screen.posts.PostsScreen

@Composable
fun HomeButtonBarNavGraph(navController: NavController) {
    NavHost(
        navController = navController as NavHostController,
        route = Graph.HOME,
        startDestination = HomeButtonBarScreen.Post.route
    ) {

        composable(HomeButtonBarScreen.Post.route) {
            PostsScreen(navController)
        }

        composable(HomeButtonBarScreen.MyPost.route) {
            MyPostsScreen(navController)
        }

        composable(HomeButtonBarScreen.Profile.route) {
            ProfileScreen(navController)
        }

        detailsNavGraph(navController)
    }
}

sealed class HomeButtonBarScreen(
    val route: String,
    var title: String,
    val icon: ImageVector
){
    object Post: HomeButtonBarScreen(
        route = "Post",
        title = "Publicaciones",
        icon = Icons.Default.List
    )
    object MyPost: HomeButtonBarScreen(
        route = "my_post",
        title = "Mis Post",
        icon = Icons.Outlined.List
    )
    object Profile: HomeButtonBarScreen(
        route = "Profile",
        title = "Perfil",
        icon = Icons.Default.Person
    )
}