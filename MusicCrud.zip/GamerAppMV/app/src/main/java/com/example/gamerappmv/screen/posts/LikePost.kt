package com.example.gamerappmv.screen.posts

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.reusable.ProgressBar

@Composable
fun LikePosts(viewModel: PostViewModel = hiltViewModel()) {
    when (val response = viewModel.likeResponse) {
        Response.Loading -> {
            ProgressBar()
        }
        is Response.Success -> {

        }
        is Response.Failure -> {
            Toast.makeText(
                LocalContext.current,
                response.exception?.message ?: "Error desconocido",
                Toast.LENGTH_LONG
            ).show()
        }
        else -> {}
    }
}