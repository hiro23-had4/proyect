package com.example.gamerappmv.screen.singup.components

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.navigation.Graph
import com.example.gamerappmv.reusable.ProgressBar

@Composable
fun SignUp(navController: NavController, viewModel: SignupViewModel = hiltViewModel()) {
    when(val signupResponse = viewModel.singupResponse) {
        Response.Loading -> {
            ProgressBar()
        }
        is Response.Success -> {
            LaunchedEffect(Unit) {
                viewModel.createUsers() // peticion exitoso al crear el usario
                navController.popBackStack(Graph.AUTHENTICATION, true)
                navController.navigate(Graph.HOME)
            }
        }
        is Response.Failure -> {
            Toast.makeText(LocalContext.current, signupResponse.exception?.message ?: "Error desconocido", Toast.LENGTH_LONG).show()
        }
        else -> {}
    }
}