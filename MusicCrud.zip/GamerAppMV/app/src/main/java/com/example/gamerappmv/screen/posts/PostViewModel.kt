package com.example.gamerappmv.screen.posts

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gamerappmv.domain.model.Post
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.use_cases.auth.AuthUseCase
import com.example.gamerappmv.domain.use_cases.post.PostUserCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PostViewModel @Inject constructor(
    private val postUserCases: PostUserCases,
    private val authUseCase: AuthUseCase
) : ViewModel() {

    var postResponse by mutableStateOf<Response<List<Post>>?>(null)
    //peticion de los likes
    var likeResponse by mutableStateOf<Response<Boolean>?>(null)
    var deleteLikeResponse by mutableStateOf<Response<Boolean>?>(null)
    var currentUser = authUseCase.getCurrentUser()

    init {
        getPost()
    }
    //likes
    fun like(idPost: String, idUser: String) = viewModelScope.launch {
        likeResponse = Response.Loading
        val result = postUserCases.likePost(idPost, idUser)
        likeResponse = result
    }

    //dislike
    fun deleteLike(idPost: String, idUser: String) = viewModelScope.launch {
        deleteLikeResponse = Response.Loading
        val result = postUserCases.deleteLikePost(idPost, idUser)
        deleteLikeResponse = result
    }


    fun getPost() = viewModelScope.launch {
        postResponse = Response.Loading
        postUserCases.getPost().collect() { response ->
            postResponse = response
        }
    }
}