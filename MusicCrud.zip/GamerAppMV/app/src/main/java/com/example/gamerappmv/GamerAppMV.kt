package com.example.gamerappmv

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp // inyecciones de dependencias
class GamerAppMV:Application() {

}