package com.example.gamerappmv.screen.posts

import android.annotation.SuppressLint
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun PostsScreen(navController: NavController, viewModel: PostViewModel = hiltViewModel()) {
    Scaffold(
        content = {
            GetPosts(navController)
        }
    )
    LikePosts()
    DeleteLikePosts()
}