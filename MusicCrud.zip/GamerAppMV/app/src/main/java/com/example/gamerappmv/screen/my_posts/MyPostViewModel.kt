package com.example.gamerappmv.screen.my_posts

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gamerappmv.domain.model.Post
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.use_cases.auth.AuthUseCase
import com.example.gamerappmv.domain.use_cases.post.PostUserCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyPostViewModel @Inject constructor(
    private val postUserCases: PostUserCases,
    private val authUseCase: AuthUseCase
) : ViewModel() {

    var postResponse by mutableStateOf<Response<List<Post>>?>(null)
    val currentUser = authUseCase.getCurrentUser()
    init {
        getPost()
    }

    fun getPost() = viewModelScope.launch {
        postResponse = Response.Loading
        postUserCases.getPostByIdUser(currentUser?.uid ?: "").collect() { response ->
            postResponse = response
        }
    }
}