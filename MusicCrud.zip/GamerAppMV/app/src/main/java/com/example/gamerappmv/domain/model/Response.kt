package com.example.gamerappmv.domain.model

sealed class Response<out T> {
    object Loading: Response<Nothing>()
    data class Success<out T>(val data: T): Response<T>() // si se almaceno correctamente.
    data class Failure<out T>(val exception: Exception?): Response<T>() // fallo al ingresar
}
