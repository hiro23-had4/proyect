package com.example.gamerappmv.navigation

import androidx.navigation.*
import androidx.navigation.compose.composable
import com.example.gamerappmv.screen.add_posts.AddPostScreen
import com.example.gamerappmv.screen.details_post.DetailPostScreen
import com.example.gamerappmv.screen.profile_edit.ProfileEditScreen

//EDIT
fun NavGraphBuilder.detailsNavGraph(navController: NavController) {
    navigation(
        route = Graph.DETAILS,
        startDestination = DetailsScreen.ProfileEditScreen.route
    ){
        composable(DetailsScreen.AddPostScreen.route) {
            AddPostScreen(navController)
        }

        composable(
            DetailsScreen.ProfileEditScreen.route,
            arguments = listOf(navArgument("user"){
                type = NavType.StringType
            })
        ) {
            it.arguments?.getString("user")?.let {//user->
                ProfileEditScreen(navController, user = it) //user
            }
        }

        composable(
            DetailsScreen.DetailPostScreen.route,
            arguments = listOf(navArgument("post"){
                type = NavType.StringType
            })
        ) {
            it.arguments?.getString("post")?.let {//user->
                DetailPostScreen(navController, post = it) //user
            }
        }
    }
}


sealed class DetailsScreen(val route: String) {
    object AddPostScreen: DetailsScreen("AddPostScreen")
    object ProfileEditScreen: DetailsScreen("ProfileEditScreen/edit/{user}") {
        fun passUser(user: String) = "ProfileEditScreen/edit/$user"
    }
    object DetailPostScreen: DetailsScreen("DetailPostScreen/detail/{post}") {
        fun passPost(post: String) = "DetailPostScreen/detail/$post"
    }
}