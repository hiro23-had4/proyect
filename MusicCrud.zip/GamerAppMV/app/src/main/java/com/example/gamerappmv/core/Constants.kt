package com.example.gamerappmv.core

// creacion de collection
object Constants {
    const val USERS = "Users"
    const val POST = "Post"
}