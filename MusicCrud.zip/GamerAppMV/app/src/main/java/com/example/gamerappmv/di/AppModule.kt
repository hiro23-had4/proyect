package com.example.gamerappmv.di

import com.example.gamerappmv.core.Constants.POST
import com.example.gamerappmv.core.Constants.USERS
import com.example.gamerappmv.data.AuthRespositoryImpl
import com.example.gamerappmv.data.PostRepositoryImp
import com.example.gamerappmv.data.UsersRepositoryImpl
import com.example.gamerappmv.domain.repository.AuthRepository
import com.example.gamerappmv.domain.repository.PostRepository
import com.example.gamerappmv.domain.repository.UsersRepository
import com.example.gamerappmv.domain.use_cases.auth.*
import com.example.gamerappmv.domain.use_cases.post.*
import com.example.gamerappmv.domain.use_cases.users.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Named

//Inyeccion de dependencies
@InstallIn(SingletonComponent::class)
@Module
object AppModule {

    // PERMITIR EL OBJETO FIREBASE
    @Provides
    fun provideFirebaseFirestore(): FirebaseFirestore = Firebase.firestore

    //STORAGE
    @Provides
    fun provideFirebaseStorage():  FirebaseStorage = FirebaseStorage.getInstance()

    //COLECCION DE IMAGE (USER)
    @Provides
    @Named(USERS)
    fun provideFirebaseStorageRef(storage: FirebaseStorage): StorageReference = storage.reference.child(
        USERS)

    //PROPORCIONAR LA COLLECTION QUE VAMOS A TRABAJAR (USERS)
    @Provides
    @Named(USERS)
    fun provideUsersRef(db: FirebaseFirestore): CollectionReference = db.collection(USERS)


    //COLECCION DE IMAGE (Post)
    @Provides
    @Named(POST) // IDENTIFICAR EL METODO ADECUADO
    fun provideStoragePostTRef(storage: FirebaseStorage): StorageReference = storage.reference.child(
        POST)

    //PROPORCIONAR LA COLLECTION QUE VAMOS A TRABAJAR (Post)
    @Provides
    @Named(POST)
    fun providePostRef(db: FirebaseFirestore): CollectionReference = db.collection(POST)



    @Provides
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    fun provideAuthRepository(impl: AuthRespositoryImpl): AuthRepository = impl

    @Provides
    fun provideUsersRepository(impl: UsersRepositoryImpl): UsersRepository = impl

    // Post Create
    @Provides
    fun providePostRepository(impl: PostRepositoryImp): PostRepository = impl

    @Provides
    fun provideAuthUseCase(repository: AuthRepository) = AuthUseCase(
        getCurrentUser = GetCurrentUser(repository),
        login = Login(repository),
        logout = Logout(repository),
        signup = Signup(repository)
    )

    @Provides
    fun provideUsersUseCase(repository: UsersRepository) = UsersUseCase(
        create = Create(repository),
        getUserById = GetUserById(repository), // usuario verificado(pasar los datos x id)
        update = Update(repository), // actualizar user
        saveImage = SaveImage(repository)
    )

    //POST
    @Provides
    fun providePostUseCase(repository: PostRepository) = PostUserCases(
        create = CreatePost(repository),
        getPost = GetPost(repository),
        getPostByIdUser = GetPostByIdUser(repository),
        likePost = LikePost(repository),
        deleteLikePost = DeleteLikePost(repository)
    )
}