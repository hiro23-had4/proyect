package com.example.gamerappmv.screen.add_posts

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.gamerappmv.reusable.ButtomPredetermined
import com.example.gamerappmv.reusable.DefaultTopBar
import com.example.gamerappmv.screen.add_posts.components.AddPost
import com.example.gamerappmv.screen.add_posts.components.AddPostContent


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddPostScreen(navController: NavController, viewModel: AddPostViewModel = hiltViewModel()) {
    Scaffold(
        topBar = {
            DefaultTopBar(
                title = "Nuevo Post",
                upAvailable = true,
                navController = navController
            )
        },
        content = {
            AddPostContent()
        },
    )
    AddPost()
}