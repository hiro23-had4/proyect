package com.example.gamerappmv.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gamerappmv.screen.home.HomeScreen

@Composable
fun RootNavGraph() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        route = Graph.ROOT, //graph principal
        startDestination = Graph.AUTHENTICATION
    ){
        //llamamos al metodo authNavGraph
        authNavGraph(navController = navController)
        composable(route = Graph.HOME) {
            HomeScreen()
        }
    }
}
