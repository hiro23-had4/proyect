package com.example.gamerappmv.navigation

//IDENTIFICAR LOS GRAPH (NAVEGACION)
object Graph {
    const val ROOT = "root_graph" //
    const val AUTHENTICATION = "auth_graph" //
    const val HOME = "home_graph" //
    const val DETAILS = "details_graph" //
}