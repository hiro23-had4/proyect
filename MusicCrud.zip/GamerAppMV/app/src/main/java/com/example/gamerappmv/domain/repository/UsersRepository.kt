package com.example.gamerappmv.domain.repository

import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.model.User
import kotlinx.coroutines.flow.Flow
import java.io.File

interface UsersRepository {

    suspend fun create(user: User): Response<Boolean> // crear usurio
    suspend fun update(user: User): Response<Boolean> // metodo para actualizar el user
    suspend fun saveImage(file: File): Response<String> //URL almacenada en FIREBASE
    //OBTENER LA INFORMACION DEL USURIO
    fun getUserById(id: String): Flow<User>
}