package com.example.gamerappmv.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
// colores establecidos
val Red200 = Color(0xFFFF7961)
val Red500 = Color(0xFFf44336)
val Red700 = Color(0xFFba000d)
// second colors
val Darkgray500 = Color(0xFF272727)
val Darkgray700 = Color(0xFF202020)
val Darkgray900 = Color(0xFF181818)
val Green200 = Color(0xFF1FDF64)