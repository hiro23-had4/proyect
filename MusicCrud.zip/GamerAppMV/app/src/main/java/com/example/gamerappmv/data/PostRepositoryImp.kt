package com.example.gamerappmv.data

import android.net.Uri
import android.util.Log
import com.example.gamerappmv.core.Constants.POST
import com.example.gamerappmv.core.Constants.USERS
import com.example.gamerappmv.domain.model.Post
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.model.User
import com.example.gamerappmv.domain.repository.PostRepository
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import javax.inject.Inject
import javax.inject.Named

class PostRepositoryImp @Inject constructor(
    @Named(POST) private val postRef: CollectionReference,
    @Named(USERS) private val userRef: CollectionReference,
    @Named(POST) private val storagePostRef: StorageReference
) : PostRepository {
    
    override fun getPost(): Flow<Response<List<Post>>> = callbackFlow {
        val snapshotListenner =
            postRef.addSnapshotListener { snapshot, error -> //escuchador de eventos
                GlobalScope.launch(Dispatchers.IO) {
                    val postResponse = if (snapshot != null) {
                        val posts = snapshot.toObjects(Post::class.java)
                        snapshot.documents.forEachIndexed { index, document ->
                            posts[index].id = document.id
                        }
                        val idUserArray = ArrayList<String>()

                        posts.forEach { post ->
                            idUserArray.add(post.idUser)
                        }

                        val idUserList = idUserArray.toSet()
                            .toList() // devolver los elementos (iduser) sin repetir

                        idUserList.map { id ->
                            async {
                                val user =
                                    userRef.document(id).get().await().toObject(User::class.java)!!
                                posts.forEach { post ->
                                    if (post.idUser == id) {
                                        post.user = user
                                    }
                                }
                                Log.d("PostRepositoryImp", "Id: ${id}")
                            }
                        }.forEach {
                            it.await()
                        }
                        Response.Success(posts)
                    } else {
                        Response.Failure(error)
                    }
                    trySend(postResponse)
                }
            }
        awaitClose {
            snapshotListenner.remove()
        }
    }

    //MY POST
    override fun getPostByUserId(idUser: String): Flow<Response<List<Post>>> = callbackFlow {
        val snapshotListenner =
            postRef.whereEqualTo("idUser", idUser)
                .addSnapshotListener { snapshot, error -> //escuchador de eventos

                    val postResponse = if (snapshot != null) {
                        val posts = snapshot.toObjects(Post::class.java)
                        snapshot.documents.forEachIndexed { index, document ->
                            posts[index].id = document.id
                        }

                        Response.Success(posts)
                    } else {
                        Response.Failure(error)
                    }
                    trySend(postResponse)
                }
        awaitClose {
            snapshotListenner.remove()
        }
    }

    override suspend fun create(post: Post, file: File): Response<Boolean> {
        return try {
            //Image
            val fromFile = Uri.fromFile(file)
            val ref = storagePostRef.child(file.name)
            val uploadTask = ref.putFile(fromFile).await()
            val url = ref.downloadUrl.await()

            //data
            post.image = url.toString()
            postRef.add(post).await()
            Response.Success(true)
        } catch (e: Exception) {
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    //LIKES FIREBASE
    override suspend fun like(idPost: String, idUser: String): Response<Boolean> {
        return try {
            postRef.document(idPost).update("likes", FieldValue.arrayUnion(idUser)).await()
            Response.Success(true)
        } catch (e: Exception) {
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    //DESLIKE FIREBASE
    override suspend fun deleteLike(idPost: String, idUser: String): Response<Boolean> {
        return try {
            postRef.document(idPost).update("likes", FieldValue.arrayRemove(idUser)).await()
            Response.Success(true)
        } catch (e: Exception) {
            e.printStackTrace()
            Response.Failure(e)
        }
    }

}