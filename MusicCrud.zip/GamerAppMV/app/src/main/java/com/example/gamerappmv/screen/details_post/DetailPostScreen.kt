package com.example.gamerappmv.screen.details_post

import android.annotation.SuppressLint
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun DetailPostScreen(navController: NavController, post: String) {
    Scaffold(
        content = {
            DetailPostContent(navController)
        }
    )
}