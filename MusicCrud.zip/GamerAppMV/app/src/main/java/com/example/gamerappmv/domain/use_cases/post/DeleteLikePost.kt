package com.example.gamerappmv.domain.use_cases.post

import com.example.gamerappmv.domain.repository.PostRepository
import javax.inject.Inject

class DeleteLikePost @Inject constructor(
    private val repository: PostRepository
) {
    suspend operator fun invoke(idPost: String, idUser: String) = repository.deleteLike(idPost, idUser)
}