package com.example.gamerappmv.screen.profile_edit

data class ProfileEditState(
    val username: String = "",
    var image: String = ""
)