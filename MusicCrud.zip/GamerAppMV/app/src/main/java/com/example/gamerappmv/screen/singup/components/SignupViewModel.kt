package com.example.gamerappmv.screen.singup.components

import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.model.User
import com.example.gamerappmv.domain.use_cases.auth.AuthUseCase
import com.example.gamerappmv.domain.use_cases.users.UsersUseCase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SignupViewModel @Inject constructor(
    private val authUseCase: AuthUseCase,
    private val usersUseCase: UsersUseCase
) : ViewModel() {

    //STATE FORM
    var state by mutableStateOf(SignupState())
        private set

    // USERNAME
    //var username by mutableStateOf("")
    var isUsernameValid by mutableStateOf(false)
        private set
    var usernameErrorMsg by mutableStateOf("")
        private set

    // EMAIL
    //var email by mutableStateOf("")
    var isEmailValid by mutableStateOf(false)
        private set
    var errorEmail by mutableStateOf("")
        private set

    // PASSWORD
    //var password: MutableState<String> = mutableStateOf("")
    var isPasswordValid by mutableStateOf(false)
        private set
    var errorPassword by mutableStateOf("")
        private set

    // CONFIRMAR CONTRASEÑA
    //var confirmPassword: MutableState<String> = mutableStateOf("")
    var isConfirmPassword by mutableStateOf(false)
        private set
    var confirmPasswordErrorMsg by mutableStateOf("")
        private set

    // ENABLE BUTTON
    var isEnabledLoginButton = false

    //===========
    var singupResponse by mutableStateOf<Response<FirebaseUser>?>(null)
        private set

    var user = User()

    fun onUsernameInput(username: String) {
        state = state.copy(username = username)
    }

    fun onEmailInput(email: String) {
        state = state.copy(email = email)
    }

    fun onPasswordInput(password: String) {
        state = state.copy(password = password)
    }

    fun onConfirmPasswordInput(confirmPassword: String) {
        state = state.copy(confirmPassword = confirmPassword)
    }


    fun onSignup() {
        user.username = state.username
        user.email = state.email
        user.password = state.password
        signup(user)
    }

    //
    fun createUsers() = viewModelScope.launch {
        user.id = authUseCase.getCurrentUser()!!.uid
        usersUseCase.create(user)
    }

    fun signup(user: User) = viewModelScope.launch {
        singupResponse = Response.Loading
        val result = authUseCase.signup(user)
        singupResponse = result
    }

    // BOTON DE VALIDACION DE CAMPOS
    fun enabledLoginButton() {
        isEnabledLoginButton =
            isUsernameValid &&
                    isEmailValid &&
                    isPasswordValid &&
                    isConfirmPassword
    }

    //VALIDACION DEL USERNAME CAMPOS
    fun validateUsername() {
        if (state.username.length >= 5) {
            isUsernameValid = true
            usernameErrorMsg = ""
        } else {
            isUsernameValid = false
            usernameErrorMsg = "Al menos 5 caracteres"
        }
        enabledLoginButton()
    }

    //VALIDACION DEL EMAIL
    fun validateEmail() {
        // Email valido
        if (Patterns.EMAIL_ADDRESS.matcher(state.email).matches()) {
            isEmailValid = true
            errorEmail = ""
        } else {
            isEmailValid = false
            errorEmail = "El Email no es valido"
        }
        enabledLoginButton()
    }

    //VALIDACION DE LA CONTRASEÑA
    fun validatePassword() {
        // password valido
        if (state.password.length >= 5) {
            isPasswordValid = true
            errorPassword = ""
        } else {
            isPasswordValid = false
            errorPassword = "Al menos 5 caracteres"
        }
        enabledLoginButton()
    }

    //CONFIRMACION DEL PASSWORD
    fun validateConfirmPassword() {
        if (state.password == state.confirmPassword) {
            isConfirmPassword = true
            confirmPasswordErrorMsg = ""
        } else {
            isConfirmPassword = false
            confirmPasswordErrorMsg = "No coincide la contraseña"
        }
        enabledLoginButton()
    }

}