package com.example.gamerappmv.screen.add_posts.components

data class AddPostState(
    val image: String = "",
    val name: String = "",
    val description: String = "",
    val category: String = "",
)
