package com.example.gamerappmv.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.example.gamerappmv.screen.login.LoginScreen
import com.example.gamerappmv.screen.singup.RegisterScreen


fun NavGraphBuilder.authNavGraph(navController: NavController) {
    navigation(
        route = Graph.AUTHENTICATION,
        startDestination = AuthScreen.LoginScreen.route
    ) {
        composable(route = AuthScreen.LoginScreen.route) {
            LoginScreen(navController)
        }
        composable(AuthScreen.RegisterScreen.route) {
            RegisterScreen(navController)
        }
    }
}

sealed class AuthScreen(val route: String) {
    object LoginScreen: AuthScreen( "LoginScreen")
    object RegisterScreen: AuthScreen( "RegisterScreen")
}