package com.example.gamerappmv.domain.repository

import com.example.gamerappmv.domain.model.Post
import com.example.gamerappmv.domain.model.Response
import kotlinx.coroutines.flow.Flow
import java.io.File

//Repository de Post
interface PostRepository {
    // Traer la informacion del post
    fun getPost(): Flow<Response<List<Post>>> //flow en tiempo real
    fun getPostByUserId(idUser: String): Flow<Response<List<Post>>>

    suspend fun create(post: Post, file: File) : Response<Boolean>
    suspend fun like(idPost: String, idUser: String): Response<Boolean> // like
    suspend fun deleteLike(idPost: String, idUser: String): Response<Boolean> // dislike
}