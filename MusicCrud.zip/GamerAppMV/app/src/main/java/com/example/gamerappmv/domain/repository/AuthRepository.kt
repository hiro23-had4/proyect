package com.example.gamerappmv.domain.repository

import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.domain.model.User
import com.google.firebase.auth.FirebaseUser

interface AuthRepository {
    val currentUser: FirebaseUser? //NOS DEVUELVE CUANDO HAGA LOGIN
    suspend fun login(email: String, password: String): Response<FirebaseUser> // debe ser suspendida
    suspend fun signUp(user: User): Response<FirebaseUser>
    fun logout()
}