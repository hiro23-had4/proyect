package com.example.gamerappmv.screen.posts

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.gamerappmv.domain.model.Response
import com.example.gamerappmv.reusable.ProgressBar

@Composable
fun GetPosts(navController: NavController, viewModel: PostViewModel = hiltViewModel()) {
    when (val response = viewModel.postResponse) {
        Response.Loading -> {
            ProgressBar()
        }
        is Response.Success -> {
            PostContent(navController, posts = response.data) //
        }
        is Response.Failure -> {
            Toast.makeText(
                LocalContext.current,
                response.exception?.message ?: "Error desconocido",
                Toast.LENGTH_LONG
            ).show()
        }
        else -> {}
    }
}