package com.example.gamerappmv.screen.login

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.gamerappmv.screen.login.components.Login
import com.example.gamerappmv.screen.login.components.LoginBottom
import com.example.gamerappmv.screen.login.components.LoginContent

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun LoginScreen(navController: NavController) {

    Scaffold(
        topBar = {},
        content = {
            LoginContent(navController)
        },
        bottomBar = {
            LoginBottom(navController)
        } // fin bottom
    )
    // MANEJAR EL ESTADO DE LA PETICION DE LOGIN
    Login(navController = navController)
}





