package com.example.gamerappmv.domain.use_cases.post

import com.example.gamerappmv.domain.repository.PostRepository
import javax.inject.Inject

class GetPost @Inject constructor(
    private val repository: PostRepository
) {
    operator fun invoke() = repository.getPost()
}