package com.example.gamerappmv.screen.profile_edit

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.gamerappmv.reusable.DefaultTopBar
import com.example.gamerappmv.screen.profile_edit.components.ProfileEditContent
import com.example.gamerappmv.screen.profile_edit.components.SaveImage
import com.example.gamerappmv.screen.profile_edit.components.Update

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun ProfileEditScreen(
    navController: NavController,
    user: String
) {
    //Log.d("ProfileEditContent", "Usuario: $user")
    Scaffold(
        topBar = {
            DefaultTopBar(
                title = "Editar Datos",
                upAvailable = true,
                navController = navController
            )
        },
        content = {
            ProfileEditContent(navController)
        },
        bottomBar = {}
    )
    SaveImage()
    Update()
}