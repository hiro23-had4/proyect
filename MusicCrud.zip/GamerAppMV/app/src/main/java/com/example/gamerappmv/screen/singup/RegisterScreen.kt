package com.example.gamerappmv.screen.singup

import android.annotation.SuppressLint
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.gamerappmv.reusable.DefaultTopBar
import com.example.gamerappmv.screen.singup.components.SignUp

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun RegisterScreen(navController: NavController) {
    Scaffold(
        topBar = {
                 DefaultTopBar(
                     title = "Nuevo Usuario",
                     upAvailable = true,
                     navController
                 )
        },
        content = {
            SingupContent(navController)
        },
        bottomBar = {}
    )
    SignUp(navController = navController)
}